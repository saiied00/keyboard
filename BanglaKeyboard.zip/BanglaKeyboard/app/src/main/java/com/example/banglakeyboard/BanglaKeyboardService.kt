package com.example.banglakeyboard

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView

class BanglaKeyboardService : InputMethodService() {

    private enum class Mode { LETTERS, SYM1, SYM2 }

    // main = shown key, hint = small top-right label, shifted = char on shift, alts = long-press choices
    private data class K(val main: String, val hint: String?, val shifted: String, val alts: List<String>)

    private var bangla = false
    private var shift = false
    private var mode = Mode.LETTERS
    private lateinit var root: LinearLayout
    private var popup: PopupWindow? = null
    private val handler = Handler(Looper.getMainLooper())

    private val KEY = 0xFF4A4A4A.toInt()
    private val SPECIAL = 0xFF2E2E2E.toInt()
    private val ACTIVE = 0xFF1E88E5.toInt()

    private val accents = mapOf(
        "a" to listOf("à", "á", "â", "ä", "ã"), "e" to listOf("é", "è", "ê", "ë"),
        "i" to listOf("í", "ì", "î", "ï"), "o" to listOf("ó", "ò", "ô", "ö", "õ"),
        "u" to listOf("ú", "ù", "û", "ü"), "c" to listOf("ç"), "n" to listOf("ñ"), "s" to listOf("ß")
    )

    private fun en(chars: String, digits: String?) = chars.mapIndexed { i, c ->
        val s = c.toString()
        val d = digits?.get(i)?.toString()
        K(s, d, s.uppercase(), listOfNotNull(d) + (accents[s] ?: emptyList()))
    }

    private val enRows = listOf(en("qwertyuiop", "1234567890"), en("asdfghjkl", null), en("zxcvbnm", null))

    private val bnRows = listOf(
        listOf(
            K("ং", "১", "ঙ", listOf("১", "ঙ", "ঃ", "ঁ")), K("য", "২", "য়", listOf("২", "য়")),
            K("ড", "৩", "ঢ", listOf("৩", "ঢ")), K("প", "৪", "ফ", listOf("৪", "ফ")),
            K("ট", "৫", "ঠ", listOf("৫", "ঠ")), K("চ", "৬", "ছ", listOf("৬", "ছ")),
            K("জ", "৭", "ঝ", listOf("৭", "ঝ")), K("হ", "৮", "ঞ", listOf("৮", "ঞ")),
            K("গ", "৯", "ঘ", listOf("৯", "ঘ")), K("ড়", "০", "ঢ়", listOf("০", "ঢ়"))
        ),
        listOf(
            K("ৃ", "ঋ", "ঋ", listOf("ঋ", "র্")), K("ু", "উ", "ূ", listOf("উ", "ূ", "ঊ")),
            K("ি", "ই", "ী", listOf("ই", "ী", "ঈ")), K("া", "আ", "অ", listOf("আ", "অ")),
            K("্", null, "্য", listOf("্র", "্য")), K("ব", "ভ", "ভ", listOf("ভ")),
            K("ক", "খ", "খ", listOf("খ", "ক্ষ")), K("ত", "ৎ", "থ", listOf("ৎ", "থ")),
            K("দ", "ধ", "ধ", listOf("ধ"))
        ),
        listOf(
            K("ঁ", "ঃ", "ঃ", listOf("ঃ")), K("ো", "ও", "ৌ", listOf("ও", "ৌ", "ঔ")),
            K("ে", "এ", "ৈ", listOf("এ", "ৈ", "ঐ")), K("র", "ল", "ল", listOf("ল")),
            K("ন", "ণ", "ণ", listOf("ণ")), K("স", "শ", "শ", listOf("শ")),
            K("ম", "ষ", "ষ", listOf("ষ"))
        )
    )

    private val sym1 = listOf(
        "1 2 3 4 5 6 7 8 9 0",
        "@ # \$ % & - + ( ) /",
        "* \" ' : ; ! ?"
    )
    private val sym2 = listOf(
        "~ ` | • ^ ° { } [ ]",
        "\\ < > = _ € £ ¥ ₹ ৳",
        "© ® ™ … § ¿ ¡"
    )
    private val symAlts = mapOf(
        "\$" to listOf("₹", "€", "£", "¥", "৳"), "-" to listOf("–", "—", "_"),
        "!" to listOf("¡"), "?" to listOf("¿"), "'" to listOf("‘", "’"), "\"" to listOf("“", "”")
    )

    private val repeat = object : Runnable {
        override fun run() { backspace(); handler.postDelayed(this, 50) }
    }

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1B1B1B.toInt())
            setPadding(dp(3), dp(6), dp(3), dp(6))
        }
        render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        shift = false
        mode = Mode.LETTERS
        if (::root.isInitialized) render()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        handler.removeCallbacks(repeat)
        popup?.dismiss()
    }

    private fun render() {
        popup?.dismiss()
        root.removeAllViews()
        if (mode == Mode.LETTERS) letterRows() else symbolRows()
        root.addView(bottomRow())
    }

    private fun letterRows() {
        val numLine = newRow(44)
        "1234567890".forEach { c ->
            val label = if (bangla) toBn(c.toString()) else c.toString()
            val v = keyView(label, null, 1f, SPECIAL, 18f)
            v.setOnClickListener { commit(label) }
            numLine.addView(v)
        }
        root.addView(numLine)
        val rows = if (bangla) bnRows else enRows
        rows.forEachIndexed { i, row ->
            val line = newRow()
            if (i == 1 && row.size == 9) line.addView(spacer(0.5f))
            if (i == 2) line.addView(special(if (shift) "⇩" else "⇧", 1.5f, if (shift) ACTIVE else SPECIAL) { shift = !shift; render() })
            row.forEach { line.addView(letterKey(it)) }
            if (i == 1 && row.size == 9) line.addView(spacer(0.5f))
            if (i == 2) line.addView(backspaceKey())
            root.addView(line)
        }
    }

    private fun letterKey(k: K): View {
        val label = if (shift) (if (bangla) k.shifted else k.main.uppercase()) else k.main
        val hint = if (shift || (k.hint != null && isNum(k.hint))) null else k.hint
        val alts = k.alts.filter { !isNum(it) }
        val v = keyView(label, hint, 1f, KEY, 20f)
        v.setOnClickListener {
            commit(label)
            if (shift) { shift = false; render() }
        }
        if (alts.isNotEmpty()) v.setOnLongClickListener {
            showAlts(v, alts.map { if (shift && !bangla) it.uppercase() else it }); true
        }
        return v
    }

    private fun symbolRows() {
        val rows = if (mode == Mode.SYM1) sym1 else sym2
        rows.forEachIndexed { i, row ->
            val line = newRow()
            if (i == 2) line.addView(special(if (mode == Mode.SYM1) "=\\<" else "?123", 1.5f, SPECIAL) {
                mode = if (mode == Mode.SYM1) Mode.SYM2 else Mode.SYM1; render()
            })
            row.split(" ").forEach { s ->
                val label = if (bangla) toBn(s) else s
                val v = keyView(label, null, 1f, KEY, 20f)
                v.setOnClickListener { commit(label) }
                symAlts[s]?.let { alts -> v.setOnLongClickListener { showAlts(v, alts); true } }
                line.addView(v)
            }
            if (i == 2) line.addView(backspaceKey())
            root.addView(line)
        }
    }

    private fun bottomRow(): View {
        val line = newRow()
        line.addView(special(if (mode == Mode.LETTERS) "?123" else "ABC", 1.5f, SPECIAL) {
            mode = if (mode == Mode.LETTERS) Mode.SYM1 else Mode.LETTERS; shift = false; render()
        })
        line.addView(special("\uD83C\uDF10", 1f, SPECIAL) { switchLanguage() })
        val comma = keyView(",", null, 1f, KEY, 20f)
        comma.setOnClickListener { commit(",") }
        line.addView(comma)
        val space = keyView(if (bangla) "বাংলা" else "English", null, 4f, KEY, 14f)
        var downX = 0f
        var swiped = false
        space.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { downX = ev.x; swiped = false; v.isPressed = true }
                MotionEvent.ACTION_MOVE -> if (!swiped && Math.abs(ev.x - downX) > dp(50)) {
                    swiped = true; switchLanguage()
                }
                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    if (!swiped && Math.abs(ev.x - downX) < dp(10)) commit(" ")
                }
                MotionEvent.ACTION_CANCEL -> v.isPressed = false
            }
            true
        }
        line.addView(space)
        val dot = keyView(if (bangla) "।" else ".", null, 1f, KEY, 20f)
        dot.setOnClickListener { commit(if (bangla) "।" else ".") }
        dot.setOnLongClickListener { showAlts(dot, listOf(".", "।", ",", "?", "!", ":", ";")); true }
        line.addView(dot)
        line.addView(special("⏎", 1.5f, SPECIAL) { enter() })
        return line
    }

    private fun switchLanguage() { bangla = !bangla; shift = false; render() }

    private fun backspaceKey(): View {
        val v = keyView("⌫", null, 1.5f, SPECIAL, 20f)
        v.setOnTouchListener { view, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { view.isPressed = true; backspace(); handler.postDelayed(repeat, 400) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { view.isPressed = false; handler.removeCallbacks(repeat) }
            }
            true
        }
        return v
    }

    private fun commit(text: String) { currentInputConnection?.commitText(text, 1) }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingText(1, 0)
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ei != null && (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun showAlts(anchor: View, alts: List<String>) {
        popup?.dismiss()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply { setColor(0xFF616161.toInt()); cornerRadius = dp(8).toFloat() }
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }
        val pw = PopupWindow(row, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false)
        alts.forEach { a ->
            row.addView(TextView(this).apply {
                text = a; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnClickListener {
                    commit(a); pw.dismiss()
                    if (shift) { shift = false; render() }
                }
            })
        }
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pw.isOutsideTouchable = true
        pw.isClippingEnabled = false
        row.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        val sw = resources.displayMetrics.widthPixels
        var x = (anchor.width - row.measuredWidth) / 2
        if (loc[0] + x < 0) x = -loc[0]
        if (loc[0] + x + row.measuredWidth > sw) x = sw - row.measuredWidth - loc[0]
        pw.showAsDropDown(anchor, x, -(anchor.height + row.measuredHeight + dp(4)))
        popup = pw
        handler.postDelayed({ if (popup === pw) pw.dismiss() }, 4000)
    }

    private fun toBn(s: String) = s.map { if (it in '0'..'9') "০১২৩৪৫৬৭৮৯"[it - '0'] else it }.joinToString("")

    private fun newRow(h: Int = 52) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h))
    }

    private fun isNum(s: String) = s.isNotEmpty() && s.all { it in '0'..'9' || it in '০'..'৯' }

    private fun spacer(w: Float) = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, w) }

    private fun special(label: String, weight: Float, color: Int, onClick: () -> Unit): View {
        val v = keyView(label, null, weight, color, 18f)
        v.setOnClickListener { onClick() }
        return v
    }

    private fun keyView(label: String, hint: String?, weight: Float, color: Int, size: Float): FrameLayout {
        val f = FrameLayout(this)
        f.background = keyBg(color)
        f.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
            .apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
        f.addView(TextView(this).apply {
            text = label; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (hint != null) {
            f.addView(TextView(this).apply {
                text = hint; textSize = 10f; setTextColor(0xFFB8B8B8.toInt())
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END).apply { setMargins(0, dp(2), dp(5), 0) })
        }
        f.isClickable = true
        return f
    }

    private fun keyBg(color: Int): Drawable {
        fun shape(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(5).toFloat() }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(0xFF7A7A7A.toInt()))
            addState(intArrayOf(), shape(color))
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
