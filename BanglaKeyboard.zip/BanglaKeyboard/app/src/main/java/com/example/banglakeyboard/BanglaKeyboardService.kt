package com.example.banglakeyboard

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView

class BanglaKeyboardService : InputMethodService() {

    private enum class Mode { LETTERS, SYM1, SYM2 }

    // main = key label, hint = small top-right label, shifted = char typed in shift mode,
    // alts = long-press choices (max 2 for Bangla; the 3rd character lives on shift)
    private data class K(
        val main: String, val hint: String?, val shifted: String, val alts: List<String>,
        val shiftHint: String? = null, val shiftAlts: List<String>? = null
    )
    private class Letter(val k: K, val main: TextView, val hint: TextView?)
    private class Page(val view: LinearLayout, val letters: MutableList<Letter>, val shiftView: FrameLayout?)
    private class PopupParts(val pw: PopupWindow, val row: LinearLayout, val tvs: List<TextView>)

    private val ROW_H = 58            // key row height in dp
    private val LONG_PRESS_MS = 200L  // long-press delay

    private var bangla = false
    private var shift = false
    private var mode = Mode.LETTERS
    private lateinit var root: LinearLayout
    private var popup: PopupWindow? = null
    private val handler = Handler(Looper.getMainLooper())
    private var letters: MutableList<Letter> = mutableListOf()
    private var shiftView: FrameLayout? = null
    private val pages = HashMap<String, Page>()
    private val popupCache = HashMap<String, PopupParts>()

    private val KEY = 0xFF4A4A4A.toInt()
    private val SPECIAL = 0xFF2E2E2E.toInt()
    private val ACTIVE = 0xFF1E88E5.toInt()

    private val accents = mapOf(
        "a" to listOf("à", "á", "â", "ä", "ã"), "e" to listOf("é", "è", "ê", "ë"),
        "i" to listOf("í", "ì", "î", "ï"), "o" to listOf("ó", "ò", "ô", "ö", "õ"),
        "u" to listOf("ú", "ù", "û", "ü"), "c" to listOf("ç"), "n" to listOf("ñ"), "s" to listOf("ß")
    )

    private fun en(chars: String) = chars.map { c ->
        val s = c.toString()
        K(s, null, s.uppercase(), accents[s] ?: emptyList())
    }

    private val enRows = listOf(en("qwertyuiop"), en("asdfghjkl"), en("zxcvbnm"))

    // Standard Bijoy layout. hint = first long-press option.
    // Keys that had 3 alternates now show 2 in the popup; the 3rd is typed with Shift.
    private val bnRows = listOf(
        listOf(
            K("ঙ", "ং", "ঁ", listOf("ং", "ঃ")), K("য", "য়", "য়", listOf("য়")),
            K("ড", "ঢ", "ঢ", listOf("ঢ")), K("প", "ফ", "ফ", listOf("ফ")),
            K("ট", "ঠ", "ঠ", listOf("ঠ")), K("চ", "ছ", "ছ", listOf("ছ")),
            K("জ", "ঝ", "ঝ", listOf("ঝ")), K("হ", "ঞ", "ঞ", listOf("ঞ")),
            K("গ", "ঘ", "ঘ", listOf("ঘ")), K("ড়", "ঢ়", "ঢ়", listOf("ঢ়"))
        ),
        listOf(
            K("ৃ", "র্", "র্", listOf("র্", "ঋ")), K("ু", "ূ", "ঊ", listOf("ূ", "উ")),
            K("ি", "ই", "ী", listOf("ই"), "ঈ", listOf("ঈ")), K("া", "আ", "অ", listOf("আ"), null, emptyList()),
            K("্", "।", "।", listOf("।")), K("ব", "ভ", "ভ", listOf("ভ")),
            K("ক", "খ", "খ", listOf("খ")), K("ত", "থ", "থ", listOf("থ", "ৎ")),
            K("দ", "ধ", "ধ", listOf("ধ"))
        ),
        listOf(
            K("্র", "্য", "্য", listOf("্য")), K("ো", "ও", "ৌ", listOf("ও"), "ঔ", listOf("ঔ")),
            K("ে", "এ", "ৈ", listOf("এ"), "ঐ", listOf("ঐ")), K("র", "ল", "ল", listOf("ল")),
            K("ন", "ণ", "ণ", listOf("ণ")), K("স", "ষ", "ষ", listOf("ষ")),
            K("ম", "শ", "শ", listOf("শ"))
        )
    )

    private val sym1 = listOf(
        "1 2 3 4 5 6 7 8 9 0",
        "@ # \$ % & - + ( ) /",
        "* \" ' : ; ! ?"
    )
    private val sym2 = listOf(
        "~ ` | • ^ ° { } [ ]",
        "\\ < > = _ € £ ¥ ₹ ৳",
        "© ® ™ … § ¿ ¡"
    )
    private val symAlts = mapOf(
        "\$" to listOf("₹", "€", "£", "¥", "৳"), "-" to listOf("–", "—", "_"),
        "!" to listOf("¡"), "?" to listOf("¿"), "'" to listOf("‘", "’"), "\"" to listOf("“", "”")
    )

    private val repeat = object : Runnable {
        override fun run() { backspace(); handler.postDelayed(this, 40) }
    }

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1B1B1B.toInt())
            setPadding(dp(3), dp(6), dp(3), dp(6))
        }
        render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        shift = false
        mode = Mode.LETTERS
        if (::root.isInitialized) render()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        handler.removeCallbacks(repeat)
        dismissPopup()
    }

    // Each page (language x mode) is built once and reused, so switching is instant.
    private fun render() {
        dismissPopup()
        val page = pages.getOrPut("$bangla-$mode") { buildPage() }
        letters = page.letters
        shiftView = page.shiftView
        root.removeAllViews()
        root.addView(page.view)
        refreshLetters()
        refreshShift()
    }

    private fun buildPage(): Page {
        val l = mutableListOf<Letter>()
        letters = l
        shiftView = null
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (mode == Mode.LETTERS) letterRows(col) else symbolRows(col)
        col.addView(bottomRow())
        return Page(col, l, shiftView)
    }

    // ---------- letters ----------

    private fun letterRows(col: LinearLayout) {
        val rows = if (bangla) bnRows else enRows
        rows.forEachIndexed { i, row ->
            val line = newRow()
            if (i == 1 && row.size == 9) line.addView(spacer(0.5f))
            if (i == 2) {
                val sv = keyView("⇧", null, 1.5f, SPECIAL, 18f)
                attach(sv) { shift = !shift; refreshShift(); refreshLetters() }
                shiftView = sv
                line.addView(sv)
            }
            row.forEach { line.addView(letterKey(it)) }
            if (i == 1 && row.size == 9) line.addView(spacer(0.5f))
            if (i == 2) line.addView(backspaceKey())
            col.addView(line)
        }
    }

    private fun labelOf(k: K) = if (shift) (if (bangla) k.shifted else k.main.uppercase()) else k.main

    private fun letterKey(k: K): View {
        val v = keyView(k.main, k.hint ?: k.shiftHint, 1f, KEY, 20f)
        letters.add(Letter(k, v.getChildAt(0) as TextView, if (v.childCount > 1) v.getChildAt(1) as TextView else null))
        val hasAlts = k.alts.isNotEmpty() || (k.shiftAlts?.isNotEmpty() == true)
        val alts: (() -> List<String>)? = if (!hasAlts) null else { { currentAlts(k) } }
        attach(v, alts) { typeKey(labelOf(k)) }
        return v
    }

    private fun currentAlts(k: K): List<String> = when {
        shift && bangla -> k.shiftAlts ?: k.alts
        shift -> k.alts.map { it.uppercase() }
        else -> k.alts
    }

    private fun typeKey(text: String) {
        commit(text)
        if (shift) { shift = false; refreshShift(); refreshLetters() }
    }

    private fun refreshLetters() {
        letters.forEach { l ->
            val t = labelOf(l.k)
            if (l.main.text != t) l.main.text = t
            l.hint?.let { h ->
                val ht = if (shift && bangla) l.k.shiftHint else l.k.hint
                if (ht == null) h.visibility = View.INVISIBLE
                else { if (h.text != ht) h.text = ht; h.visibility = View.VISIBLE }
            }
        }
    }

    private fun refreshShift() {
        shiftView?.let {
            it.background = keyBg(if (shift) ACTIVE else SPECIAL)
            (it.getChildAt(0) as TextView).text = if (shift) "⇩" else "⇧"
        }
    }

    // ---------- symbols ----------

    private fun symbolRows(col: LinearLayout) {
        val rows = if (mode == Mode.SYM1) sym1 else sym2
        rows.forEachIndexed { i, row ->
            val line = newRow()
            if (i == 2) {
                val t = keyView(if (mode == Mode.SYM1) "=\\<" else "?123", null, 1.5f, SPECIAL, 18f)
                attach(t) { mode = if (mode == Mode.SYM1) Mode.SYM2 else Mode.SYM1; render() }
                line.addView(t)
            }
            row.split(" ").forEach { s ->
                val label = if (bangla) toBn(s) else s
                val v = keyView(label, null, 1f, KEY, 20f)
                val a = symAlts[s]
                attach(v, if (a == null) null else ({ a })) { commit(label) }
                line.addView(v)
            }
            if (i == 2) line.addView(backspaceKey())
            col.addView(line)
        }
    }

    // ---------- bottom row ----------

    private fun bottomRow(): View {
        val line = newRow()
        val sym = keyView(if (mode == Mode.LETTERS) "?123" else "ABC", null, 1.5f, SPECIAL, 18f)
        attach(sym) { mode = if (mode == Mode.LETTERS) Mode.SYM1 else Mode.LETTERS; shift = false; render() }
        line.addView(sym)

        val comma = keyView(",", null, 1f, KEY, 20f)
        attach(comma) { commit(",") }
        line.addView(comma)

        line.addView(spaceKey())

        val dotChar = if (bangla) "।" else "."
        val dot = keyView(dotChar, null, 1f, KEY, 20f)
        val dotAlts = if (bangla) listOf(".", "?", "!", ":", ";") else listOf("!", "?", ":", ";", "।")
        attach(dot, { dotAlts }) { commit(dotChar) }
        line.addView(dot)

        val enter = keyView("⏎", null, 1.5f, SPECIAL, 20f)
        attach(enter) { enter() }
        line.addView(enter)
        return line
    }

    private fun spaceKey(): View {
        val v = keyView(if (bangla) "বাংলা  ⇆  English" else "English  ⇆  বাংলা", null, 5f, KEY, 13f)
        var downX = 0f
        var swiped = false
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; swiped = false; view.isPressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                }
                MotionEvent.ACTION_MOVE -> if (!swiped && Math.abs(ev.rawX - downX) > dp(50)) {
                    swiped = true; view.isPressed = false
                    view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    switchLanguage()
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    if (!swiped) commit(" ")
                }
                MotionEvent.ACTION_CANCEL -> view.isPressed = false
            }
            true
        }
        return v
    }

    private fun switchLanguage() { bangla = !bangla; shift = false; render() }

    private fun backspaceKey(): View {
        val v = keyView("⌫", null, 1.5f, SPECIAL, 20f)
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    backspace(); handler.postDelayed(repeat, 350)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false; handler.removeCallbacks(repeat)
                }
            }
            true
        }
        return v
    }

    // ---------- input ----------

    private fun commit(text: String) { currentInputConnection?.commitText(text, 1) }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingText(1, 0)
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ei != null && (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    // ---------- touch + long-press popup ----------
    // Keys with no alternates type instantly on touch-down.
    // Keys with alternates: quick tap types the key on release; hold to open the popup,
    // slide to an option and release to type it (release without sliding types the first one).

    private fun attach(v: View, alts: (() -> List<String>)? = null, tap: () -> Unit) {
        var longShown = false
        var options: List<TextView> = emptyList()
        var values: List<String> = emptyList()
        var sel = 0
        val longPress = Runnable {
            val list = alts?.invoke() ?: return@Runnable
            if (list.isEmpty()) return@Runnable
            values = list
            options = showAlts(v, list)
            sel = 0
            highlight(options, sel)
            longShown = true
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        }
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    longShown = false
                    view.isPressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    if (alts == null) tap() else handler.postDelayed(longPress, LONG_PRESS_MS)
                }
                MotionEvent.ACTION_MOVE -> if (longShown) {
                    val idx = optionAt(options, ev.rawX)
                    if (idx != sel) { sel = idx; highlight(options, sel) }
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    handler.removeCallbacks(longPress)
                    if (longShown) {
                        val chosen = values[sel]
                        dismissPopup()
                        typeKey(chosen)
                    } else if (alts != null) tap()
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    handler.removeCallbacks(longPress)
                    if (longShown) dismissPopup()
                }
            }
            true
        }
    }

    private fun buildPopup(alts: List<String>): PopupParts {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply { setColor(0xFF616161.toInt()); cornerRadius = dp(8).toFloat() }
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val tvs = alts.map { a ->
            TextView(this).apply {
                text = a; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                minWidth = dp(40)
                setPadding(dp(10), dp(8), dp(10), dp(8))
            }.also { row.addView(it) }
        }
        val pw = PopupWindow(row, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pw.isTouchable = false
        pw.isClippingEnabled = false
        row.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        return PopupParts(pw, row, tvs)
    }

    private fun showAlts(anchor: View, alts: List<String>): List<TextView> {
        dismissPopup()
        val key = System.identityHashCode(anchor).toString() + "|" + alts.joinToString("|")
        val parts = popupCache.getOrPut(key) { buildPopup(alts) }
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        val sw = resources.displayMetrics.widthPixels
        val w = parts.row.measuredWidth
        var x = (anchor.width - w) / 2
        if (loc[0] + x < 0) x = -loc[0]
        if (loc[0] + x + w > sw) x = sw - w - loc[0]
        parts.pw.showAsDropDown(anchor, x, -(anchor.height + parts.row.measuredHeight + dp(4)))
        popup = parts.pw
        return parts.tvs
    }

    private fun optionAt(options: List<TextView>, rawX: Float): Int {
        if (options.isEmpty()) return 0
        val loc = IntArray(2)
        options.first().getLocationOnScreen(loc)
        if (options.first().width > 0 && rawX < loc[0]) return 0
        options.forEachIndexed { i, tv ->
            tv.getLocationOnScreen(loc)
            if (tv.width > 0 && rawX >= loc[0] && rawX < loc[0] + tv.width) return i
        }
        return options.size - 1
    }

    private fun highlight(options: List<TextView>, sel: Int) {
        options.forEachIndexed { i, tv ->
            tv.setBackgroundColor(if (i == sel) ACTIVE else Color.TRANSPARENT)
        }
    }

    private fun dismissPopup() { popup?.dismiss(); popup = null }

    // ---------- views ----------

    private fun toBn(s: String) = s.map { if (it in '0'..'9') "০১২৩৪৫৬৭৮৯"[it - '0'] else it }.joinToString("")

    private fun newRow() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ROW_H))
    }

    private fun spacer(w: Float) = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, w) }

    private fun keyView(label: String, hint: String?, weight: Float, color: Int, size: Float): FrameLayout {
        val f = FrameLayout(this)
        f.background = keyBg(color)
        f.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
            .apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
        f.addView(TextView(this).apply {
            text = label; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (hint != null) {
            f.addView(TextView(this).apply {
                text = hint; textSize = 10f; setTextColor(0xFFB8B8B8.toInt())
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END).apply { setMargins(0, dp(2), dp(5), 0) })
        }
        return f
    }

    private fun keyBg(color: Int): Drawable {
        fun shape(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(5).toFloat() }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(0xFF7A7A7A.toInt()))
            addState(intArrayOf(), shape(color))
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
