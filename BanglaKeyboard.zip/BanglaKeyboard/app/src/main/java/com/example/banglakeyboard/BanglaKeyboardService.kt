package com.example.banglakeyboard

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class BanglaKeyboardService : InputMethodService() {

    private enum class Mode { LETTERS, SYM1, SYM2 }

    // main = key label, hint = small top-right label (what long-press gives),
    // shifted = char typed in shift mode, alts = long-press choices,
    // shiftHint / shiftAlts = hint and long-press choices while shift is on.
    private data class K(
        val main: String, val hint: String?, val shifted: String, val alts: List<String>,
        val shiftHint: String? = null, val shiftAlts: List<String>? = null
    )
    private class Letter(val k: K, val main: TextView, val hint: TextView?)
    private class Page(val view: LinearLayout, val letters: MutableList<Letter>, val shiftView: FrameLayout?)
    private class PopupParts(val pw: PopupWindow, val row: LinearLayout, val tvs: List<TextView>)

    private var rowH = 58             // key row height in dp (changeable in settings)
    private val LONG_PRESS_MS = 170L

    private var bangla = false
    private var shift = false
    private var caps = false
    private var lastShiftTap = 0L
    private var lastCommitLen = 0
    private var mode = Mode.LETTERS
    private lateinit var root: LinearLayout
    private var popup: PopupWindow? = null
    private val handler = Handler(Looper.getMainLooper())
    private var letters: MutableList<Letter> = mutableListOf()
    private var shiftView: FrameLayout? = null
    private val pages = HashMap<String, Page>()
    private val popupCache = HashMap<String, PopupParts>()

    private val KEY = 0x40FFFFFF
    private val SPECIAL = 0x24FFFFFF
    private val ACTIVE = 0xFF1E88E5.toInt()

    private val emojiCats = listOf(
        "😀" to listOf("😀","😃","😄","😁","😆","😅","😂","🤣","😊","😇","🙂","😉","😍","🥰","😘","😗","😋","😛","😜","🤪","😎","🤩","🥳","😏","😒","😞","😔","😟","😕","🙁","😣","😖","😫","😩","🥺","😢","😭","😤","😠","😡","🤬","🤯","😳","🥵","🥶","😱","😨","😰","😥","😓","🤗","🤔","🤭","🤫","😶","😐","😑","😬","🙄","😴","🤤","😷","🤒","🤕","🤢","🤮","🥴","😵"),
        "👍" to listOf("👍","👎","👌","✌️","🤞","🤟","🤘","🤙","👈","👉","👆","👇","☝️","✋","🤚","👋","👏","🙌","👐","🤝","🙏","💪","❤️","🧡","💛","💚","💙","💜","🖤","🤍","💔","❣️","💕","💞","💓","💗","💖","💘","💝","💯","✨"),
        "🐶" to listOf("🐶","🐱","🐭","🐹","🐰","🦊","🐻","🐼","🐨","🐯","🦁","🐮","🐷","🐸","🐵","🐔","🐧","🐦","🦆","🦉","🐝","🦋","🐢","🐍","🐟","🐬","🌹","🌸","🌻","🌳","🍎","🍌","🍇","🍓","🍉","🍕","🍔","🍟","🍗","🍰","🍫","☕","🍺"),
        "🎉" to listOf("🎉","🎊","🎁","🎂","🎈","🔥","⭐","🌟","⚡","🌈","☀️","🌙","☁️","💧","🏠","🚗","✈️","📱","💻","📷","🎵","🎶","⚽","🏆","✅","❌","⚠️","❓","❗","💡","🔔","💰","🎯","✔️","➕","➖","🔒","🔑","📚","✏️","🕐")
    )

    private val accents = mapOf(
        "a" to listOf("à", "á", "â", "ä", "ã"), "e" to listOf("é", "è", "ê", "ë"),
        "i" to listOf("í", "ì", "î", "ï"), "o" to listOf("ó", "ò", "ô", "ö", "õ"),
        "u" to listOf("ú", "ù", "û", "ü"), "c" to listOf("ç"), "n" to listOf("ñ"), "s" to listOf("ß")
    )

    private fun en(chars: String) = chars.map { c ->
        val s = c.toString()
        K(s, null, s.uppercase(), accents[s] ?: emptyList())
    }

    private val enRows = listOf(en("qwertyuiop"), en("asdfghjkl"), en("zxcvbnm"))

    private val bnRows = listOf(
        listOf(
            K("ঙ", "ং", "ঁ", listOf("ং"), "ঃ", listOf("ঃ")), K("য", "য়", "য়", listOf("য়")),
            K("ড", "ঢ", "ঢ", listOf("ঢ")), K("প", "ফ", "ফ", listOf("ফ")),
            K("ট", "ঠ", "ঠ", listOf("ঠ")), K("চ", "ছ", "ছ", listOf("ছ")),
            K("জ", "ঝ", "ঝ", listOf("ঝ")), K("হ", "ঞ", "ঞ", listOf("ঞ")),
            K("গ", "ঘ", "ঘ", listOf("ঘ")), K("ড়", "ঢ়", "ঢ়", listOf("ঢ়"))
        ),
        listOf(
            K("ৃ", "ঋ", "র্", listOf("ঋ"), null, emptyList()), K("ু", "উ", "ূ", listOf("উ"), "ঊ", listOf("ঊ")),
            K("ি", "ই", "ী", listOf("ই"), "ঈ", listOf("ঈ")), K("া", "আ", "অ", listOf("আ"), null, emptyList()),
            K("্", "।", "।", listOf("।")), K("ব", "ভ", "ভ", listOf("ভ")),
            K("ক", "খ", "খ", listOf("খ")), K("ত", "থ", "থ", listOf("থ", "ৎ")),
            K("দ", "ধ", "ধ", listOf("ধ"))
        ),
        listOf(
            K("্র", "্য", "্য", listOf("্য")), K("ো", "ও", "ৌ", listOf("ও"), "ঔ", listOf("ঔ")),
            K("ে", "এ", "ৈ", listOf("এ"), "ঐ", listOf("ঐ")), K("র", "ল", "ল", listOf("ল")),
            K("ন", "ণ", "ণ", listOf("ণ")), K("স", "ষ", "ষ", listOf("ষ")),
            K("ম", "শ", "শ", listOf("শ"))
        )
    )

    private val sym1 = listOf(
        "1 2 3 4 5 6 7 8 9 0",
        "@ # \$ % & - + ( ) /",
        "* \" ' : ; ! ?"
    )
    private val sym2 = listOf(
        "~ ` | • ^ ° { } [ ]",
        "\\ < > = _ € £ ¥ ₹ ৳",
        "© ® ™ … § ¿ ¡"
    )
    private val symAlts = mapOf(
        "\$" to listOf("₹", "€", "£", "¥", "৳"), "-" to listOf("–", "—", "_"),
        "!" to listOf("¡"), "?" to listOf("¿"), "'" to listOf("‘", "’"), "\"" to listOf("“", "”")
    )

    private val repeat = object : Runnable {
        override fun run() { backspace(); handler.postDelayed(this, 40) }
    }

    override fun onCreate() {
        super.onCreate()
        rowH = getSharedPreferences("kb", MODE_PRIVATE).getInt("rowH", 58)
    }

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glassRoot()
            setPadding(dp(3), dp(6), dp(3), dp(6))
        }
        runCatching { window.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)) }
        // Real blur of whatever is behind the keyboard (Android 12+ on supported phones)
        if (Build.VERSION.SDK_INT >= 31) runCatching { window.window?.setBackgroundBlurRadius(90) }
        render(false)
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        shift = false; caps = false
        mode = Mode.LETTERS
        if (::root.isInitialized) render(false)
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        handler.removeCallbacks(repeat)
        dismissPopup()
    }

    // Each page (language x mode) is built once and reused, so switching is instant.
    private fun render(animate: Boolean = true) {
        dismissPopup()
        val page = pages.getOrPut("$bangla-$mode") { buildPage() }
        letters = page.letters
        shiftView = page.shiftView
        root.removeAllViews()
        root.addView(page.view)
        refreshLetters()
        refreshShift()
        if (animate) {
            page.view.alpha = 0.35f
            page.view.animate().alpha(1f).setDuration(140).start()
        } else page.view.alpha = 1f
    }

    private fun buildPage(): Page {
        val l = mutableListOf<Letter>()
        letters = l
        shiftView = null
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (mode == Mode.LETTERS) letterRows(col) else symbolRows(col)
        col.addView(bottomRow())
        return Page(col, l, shiftView)
    }

    private fun resetShift() { shift = false; caps = false }

    // ---------- letters ----------

    private fun letterRows(col: LinearLayout) {
        val rows = if (bangla) bnRows else enRows
        rows.forEachIndexed { i, row ->
            val line = newRow()
            if (i == 1 && row.size == 9) line.addView(spacer(0.5f))
            if (i == 2) {
                val sv = keyView("⇧", null, 1.5f, SPECIAL, 18f)
                attach(sv) { onShiftTap() }
                shiftView = sv
                line.addView(sv)
            }
            row.forEach { line.addView(letterKey(it)) }
            if (i == 1 && row.size == 9) line.addView(spacer(0.5f))
            if (i == 2) line.addView(backspaceKey())
            col.addView(line)
        }
    }

    // Tap = one-shot shift. Double tap = caps lock. Tap again = off.
    private fun onShiftTap() {
        val now = SystemClock.uptimeMillis()
        when {
            caps -> { caps = false; shift = false }
            shift && now - lastShiftTap < 350 -> caps = true
            else -> shift = !shift
        }
        lastShiftTap = now
        refreshShift(); refreshLetters()
    }

    private fun labelOf(k: K) = if (shift) (if (bangla) k.shifted else k.main.uppercase()) else k.main

    private fun letterKey(k: K): View {
        val v = keyView(k.main, k.hint ?: k.shiftHint, 1f, KEY, 20f)
        letters.add(Letter(k, v.getChildAt(0) as TextView, if (v.childCount > 1) v.getChildAt(1) as TextView else null))
        val hasAlts = k.alts.isNotEmpty() || (k.shiftAlts?.isNotEmpty() == true)
        val alts: (() -> List<String>)? = if (!hasAlts) null else { { currentAlts(k) } }
        attach(v, alts) { typeKey(labelOf(k)) }
        return v
    }

    private fun currentAlts(k: K): List<String> = when {
        shift && bangla -> k.shiftAlts ?: k.alts
        shift -> k.alts.map { it.uppercase() }
        else -> k.alts
    }

    private fun typeKey(text: String) {
        commit(text)
        if (shift && !caps) { shift = false; refreshShift(); refreshLetters() }
    }

    private fun refreshLetters() {
        letters.forEach { l ->
            val t = labelOf(l.k)
            if (l.main.text != t) l.main.text = t
            l.hint?.let { h ->
                val ht = if (shift && bangla) l.k.shiftHint else l.k.hint
                if (ht == null) h.visibility = View.INVISIBLE
                else { if (h.text != ht) h.text = ht; h.visibility = View.VISIBLE }
            }
        }
    }

    private fun refreshShift() {
        shiftView?.let {
            it.background = keyBg(if (shift) ACTIVE else SPECIAL)
            (it.getChildAt(0) as TextView).text = if (caps) "⇪" else if (shift) "⇩" else "⇧"
        }
    }

    // ---------- symbols ----------

    private fun symbolRows(col: LinearLayout) {
        val rows = if (mode == Mode.SYM1) sym1 else sym2
        rows.forEachIndexed { i, row ->
            val line = newRow()
            if (i == 2) {
                val t = keyView(if (mode == Mode.SYM1) "=\\<" else "?123", null, 1.5f, SPECIAL, 18f)
                attach(t) { mode = if (mode == Mode.SYM1) Mode.SYM2 else Mode.SYM1; render() }
                line.addView(t)
            }
            row.split(" ").forEach { s ->
                val label = if (bangla) toBn(s) else s
                val v = keyView(label, null, 1f, KEY, 20f)
                val a = symAlts[s]
                attach(v, if (a == null) null else ({ a })) { commit(label) }
                line.addView(v)
            }
            if (i == 2) line.addView(backspaceKey())
            col.addView(line)
        }
    }

    // ---------- bottom row ----------

    private fun bottomRow(): View {
        val line = newRow()
        val sym = keyView(if (mode == Mode.LETTERS) "?123" else "ABC", null, 1.5f, SPECIAL, 18f)
        attach(sym) { mode = if (mode == Mode.LETTERS) Mode.SYM1 else Mode.LETTERS; resetShift(); render() }
        line.addView(sym)

        // comma: hold to get the emoji key, release to open the emoji panel
        val comma = keyView(",", null, 1f, KEY, 20f)
        attach(comma, { listOf("😀") }, { openEmoji() }) { commit(",") }
        line.addView(comma)

        line.addView(spaceKey())

        val dotChar = if (bangla) "।" else "."
        val dot = keyView(dotChar, null, 1f, KEY, 20f)
        val dotAlts = if (bangla) listOf(".", "?", "!", ":", ";") else listOf("!", "?", ":", ";", "।")
        attach(dot, { dotAlts }) { commit(dotChar) }
        line.addView(dot)

        // enter: hold for settings
        val enter = keyView("⏎", null, 1.5f, SPECIAL, 20f)
        attach(enter, { listOf("⚙ সেটিং") }, { openSettings() }, false) { enter() }
        line.addView(enter)
        return line
    }

    private fun spaceKey(): View {
        val v = keyView(if (bangla) "বাংলা  ⇆  English" else "English  ⇆  বাংলা", null, 5f, KEY, 13f)
        var downX = 0f
        var swiped = false
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; swiped = false; view.isPressed = true
                    pressAnim(view, true)
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                }
                MotionEvent.ACTION_MOVE -> if (!swiped && Math.abs(ev.rawX - downX) > dp(50)) {
                    swiped = true; view.isPressed = false; pressAnim(view, false)
                    view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    switchLanguage()
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false; pressAnim(view, false)
                    if (!swiped) commit(" ")
                }
                MotionEvent.ACTION_CANCEL -> { view.isPressed = false; pressAnim(view, false) }
            }
            true
        }
        return v
    }

    private fun switchLanguage() { bangla = !bangla; resetShift(); render() }

    private fun backspaceKey(): View {
        val v = keyView("⌫", null, 1.5f, SPECIAL, 20f)
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true; pressAnim(view, true)
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    backspace(); handler.postDelayed(repeat, 350)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false; pressAnim(view, false); handler.removeCallbacks(repeat)
                }
            }
            true
        }
        return v
    }

    // ---------- settings panel ----------

    private fun openSettings() {
        dismissPopup()
        var h = rowH
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(0x1AFFFFFF); cornerRadius = dp(18).toFloat(); setStroke(dp(1), 0x40FFFFFF) }
            setPadding(dp(18), dp(10), dp(18), dp(10))
            minimumHeight = dp(rowH) * 4
        }
        panel.addView(TextView(this).apply { text = "⚙ সেটিং"; textSize = 18f; setTextColor(Color.WHITE) })
        val label = TextView(this).apply {
            text = "কিবোর্ডের উচ্চতা: $h"; textSize = 14f; setTextColor(Color.WHITE)
            setPadding(0, dp(14), 0, dp(4))
        }
        panel.addView(label)
        val bar = SeekBar(this).apply {
            max = 28; progress = h - 44
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    h = 44 + p; label.text = "কিবোর্ডের উচ্চতা: $h"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        panel.addView(bar)
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }
        buttons.addView(pill("রিসেট") { h = 58; bar.progress = 14; label.text = "কিবোর্ডের উচ্চতা: $h" })
        buttons.addView(pill("ঠিক আছে") { applyHeight(h) })
        panel.addView(buttons)
        root.removeAllViews()
        root.addView(panel)
    }

 // ---------- emoji panel ----------

    private fun openEmoji() {
        dismissPopup()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(0x1AFFFFFF); cornerRadius = dp(18).toFloat(); setStroke(dp(1), 0x40FFFFFF) }
        }
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40))
        }
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(rowH * 3 - 40))
        }
        val tabViews = mutableListOf<TextView>()

        fun showCat(idx: Int) {
            tabViews.forEachIndexed { i, t ->
                t.background = if (i == idx) GradientDrawable().apply { setColor(ACTIVE); cornerRadius = dp(14).toFloat() } else null
            }
            val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            emojiCats[idx].second.chunked(8).forEach { chunk ->
                val r = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
                }
                chunk.forEach { e ->
                    r.addView(TextView(this).apply {
                        text = e; textSize = 26f; gravity = Gravity.CENTER
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                        setOnClickListener {
                            it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            commit(e)
                        }
                    })
                }
                repeat(8 - chunk.size) {
                    r.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })
                }
                grid.addView(r)
            }
            scroll.removeAllViews()
            scroll.addView(grid)
            scroll.scrollTo(0, 0)
        }

        emojiCats.forEachIndexed { i, c ->
            val t = TextView(this).apply {
                text = c.first; textSize = 20f; gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                    .apply { setMargins(dp(4), dp(3), dp(4), dp(3)) }
                setOnClickListener { showCat(i) }
            }
            tabViews.add(t); tabs.addView(t)
        }
        panel.addView(tabs)
        panel.addView(scroll)

        val bottom = newRow()
        val abc = keyView("ABC", null, 1.5f, SPECIAL, 18f)
        attach(abc) { render() }
        bottom.addView(abc)
        val sp = keyView("", null, 5f, KEY, 13f)
        attach(sp) { commit(" ") }
        bottom.addView(sp)
        bottom.addView(backspaceKey())
        panel.addView(bottom)

        showCat(0)
        root.removeAllViews()
        root.addView(panel)
    }

    private fun pill(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = GradientDrawable().apply { setColor(ACTIVE); cornerRadius = dp(22).toFloat() }
        layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(6), 0, dp(6), 0) }
        setOnClickListener { onClick() }
    }

    private fun applyHeight(h: Int) {
        rowH = h
        getSharedPreferences("kb", MODE_PRIVATE).edit().putInt("rowH", h).apply()
        pages.clear()
        popupCache.clear()
        render()
    }

    // ---------- input ----------

    private fun commit(text: String) {
        lastCommitLen = text.length
        currentInputConnection?.commitText(text, 1)
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingText(1, 0)
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ei != null && (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    // ---------- touch + long-press popup ----------
    // instant = true: the key types the moment it is touched (fast). If you keep holding,
    //   that character is replaced by the popup (slide to an option and release).
    // instant = false: the tap action runs on release (used for Enter).

    private fun attach(
        v: View,
        alts: (() -> List<String>)? = null,
        onPick: ((String) -> Unit)? = null,
        instant: Boolean = true,
        tap: () -> Unit
    ) {
        var longShown = false
        var tappedOnDown = false
        var pending: List<String> = emptyList()
        var options: List<TextView> = emptyList()
        var sel = 0
        val longPress = Runnable {
            if (pending.isEmpty()) return@Runnable
            if (tappedOnDown) {
                currentInputConnection?.deleteSurroundingText(lastCommitLen, 0)
                tappedOnDown = false
            }
            options = showAlts(v, pending)
            sel = 0
            highlight(options, sel)
            longShown = true
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        }
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    longShown = false; tappedOnDown = false
                    view.isPressed = true
                    pressAnim(view, true)
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    pending = alts?.invoke() ?: emptyList()
                    if (pending.isEmpty()) {
                        tap(); tappedOnDown = true
                    } else {
                        if (instant) { tap(); tappedOnDown = true }
                        handler.postDelayed(longPress, LONG_PRESS_MS)
                    }
                }
                MotionEvent.ACTION_MOVE -> if (longShown) {
                    val idx = optionAt(options, ev.rawX, ev.rawY)
                    if (idx != sel) { sel = idx; highlight(options, sel) }
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    pressAnim(view, false)
                    handler.removeCallbacks(longPress)
                    if (longShown) {
                        val chosen = pending[sel]
                        dismissPopup()
                        if (onPick != null) onPick(chosen) else typeKey(chosen)
                    } else if (!tappedOnDown) tap()
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    pressAnim(view, false)
                    handler.removeCallbacks(longPress)
                    if (longShown) dismissPopup()
                }
            }
            true
        }
    }

    private fun pressAnim(v: View, down: Boolean) {
        v.animate().cancel()
        v.animate().scaleX(if (down) 0.9f else 1f).scaleY(if (down) 0.9f else 1f)
            .setDuration(if (down) 60L else 110L).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun buildPopup(alts: List<String>): PopupParts {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(0xEE2B3240.toInt()); cornerRadius = dp(18).toFloat(); setStroke(dp(1), 0x66FFFFFF) }
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val cols = if (alts.size > 8) 6 else alts.size
        val tvs = mutableListOf<TextView>()
        alts.chunked(cols).forEach { chunk ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            chunk.forEach { a ->
                val tv = TextView(this).apply {
                    text = a; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                    minWidth = dp(40)
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                r.addView(tv); tvs.add(tv)
            }
            box.addView(r)
        }
        val pw = PopupWindow(box, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pw.isTouchable = false
        pw.isClippingEnabled = false
        box.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        return PopupParts(pw, box, tvs)
    }

    private fun showAlts(anchor: View, alts: List<String>): List<TextView> {
        dismissPopup()
        val key = System.identityHashCode(anchor).toString() + "|" + alts.joinToString("|")
        val parts = popupCache.getOrPut(key) { buildPopup(alts) }
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        val sw = resources.displayMetrics.widthPixels
        val w = parts.row.measuredWidth
        var x = (anchor.width - w) / 2
        if (loc[0] + x < 0) x = -loc[0]
        if (loc[0] + x + w > sw) x = sw - w - loc[0]
        parts.pw.showAsDropDown(anchor, x, -(anchor.height + parts.row.measuredHeight + dp(4)))
        parts.row.pivotX = w / 2f
        parts.row.pivotY = parts.row.measuredHeight.toFloat()
        parts.row.alpha = 0f
        parts.row.scaleX = 0.8f
        parts.row.scaleY = 0.8f
        parts.row.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(90).start()
        popup = parts.pw
        return parts.tvs
    }

    private fun optionAt(options: List<TextView>, rawX: Float, rawY: Float): Int {
        if (options.isEmpty()) return 0
        val multiRow = options.size > 8
        val loc = IntArray(2)
        var best = 0
        var bestD = Float.MAX_VALUE
        options.forEachIndexed { i, tv ->
            if (tv.width == 0) return@forEachIndexed
            tv.getLocationOnScreen(loc)
            val dx = rawX - (loc[0] + tv.width / 2f)
            val dy = rawY - (loc[1] + tv.height / 2f)
            val d = dx * dx + (if (multiRow) dy * dy else 0f)
            if (d < bestD) { bestD = d; best = i }
        }
        return best
    }

    private fun highlight(options: List<TextView>, sel: Int) {
        options.forEachIndexed { i, tv ->
            tv.background = if (i == sel)
                GradientDrawable().apply { setColor(ACTIVE); cornerRadius = dp(14).toFloat() }
            else null
        }
    }

    private fun dismissPopup() { popup?.dismiss(); popup = null }

    // ---------- views ----------

    private fun toBn(s: String) = s.map { if (it in '0'..'9') "০১২৩৪৫৬৭৮৯"[it - '0'] else it }.joinToString("")

    private fun newRow() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(rowH))
    }

    private fun spacer(w: Float) = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, w) }

    private fun keyView(label: String, hint: String?, weight: Float, color: Int, size: Float): FrameLayout {
        val f = FrameLayout(this)
        f.background = keyBg(color)
        f.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
            .apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
        f.addView(TextView(this).apply {
            text = label; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setShadowLayer(4f, 0f, 1f, 0x80000000.toInt())
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (hint != null) {
            f.addView(TextView(this).apply {
                text = hint; textSize = 10f; setTextColor(0xCCFFFFFF.toInt())
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END).apply { setMargins(0, dp(3), dp(7), 0) })
        }
        return f
    }

    private fun scaleAlpha(c: Int, f: Float): Int {
        val a = (((c ushr 24) and 0xFF) * f).toInt().coerceIn(0, 255)
        return (a shl 24) or (c and 0x00FFFFFF)
    }

    // Frosted dark-glass panel that sits behind all keys
    private fun glassRoot(): Drawable {
        val r = dp(26).toFloat()
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x6618222E, 0x4D0E141C)).apply {
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            setStroke(dp(1), 0x40FFFFFF)
        }
    }

    // Liquid-glass key: soft top highlight fading down, thin bright rim, brighter when pressed
    private fun keyBg(color: Int): Drawable {
        fun glass(top: Int, bottom: Int, rim: Int) =
            GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), rim)
            }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), glass(0x99FFFFFF.toInt(), 0x66FFFFFF, 0xCCFFFFFF.toInt()))
            addState(intArrayOf(), glass(color, scaleAlpha(color, 0.55f), 0x66FFFFFF))
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
