package com.example.banglakeyboard

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView

class BanglaKeyboardService : InputMethodService() {

    private enum class Mode { LETTERS, SYM1, SYM2 }

    // main = key label, hint = small top-right label, shifted = char on shift, alts = long-press choices
    private data class K(val main: String, val hint: String?, val shifted: String, val alts: List<String>)
    private class Letter(val k: K, val main: TextView, val hint: TextView?)

    private var bangla = false
    private var shift = false
    private var mode = Mode.LETTERS
    private lateinit var root: LinearLayout
    private var popup: PopupWindow? = null
    private val handler = Handler(Looper.getMainLooper())
    private val letters = mutableListOf<Letter>()
    private var shiftView: FrameLayout? = null

    private val KEY = 0xFF4A4A4A.toInt()
    private val SPECIAL = 0xFF2E2E2E.toInt()
    private val ACTIVE = 0xFF1E88E5.toInt()

    private val accents = mapOf(
        "a" to listOf("à", "á", "â", "ä", "ã"), "e" to listOf("é", "è", "ê", "ë"),
        "i" to listOf("í", "ì", "î", "ï"), "o" to listOf("ó", "ò", "ô", "ö", "õ"),
        "u" to listOf("ú", "ù", "û", "ü"), "c" to listOf("ç"), "n" to listOf("ñ"), "s" to listOf("ß")
    )

    private fun en(chars: String, digits: String?) = chars.mapIndexed { i, c ->
        val s = c.toString()
        val d = digits?.get(i)?.toString()
        K(s, d, s.uppercase(), listOfNotNull(d) + (accents[s] ?: emptyList()))
    }

    private val enRows = listOf(en("qwertyuiop", "1234567890"), en("asdfghjkl", null), en("zxcvbnm", null))

    private val bnRows = listOf(
        listOf(
            K("ং", "১", "ঙ", listOf("১", "ঙ", "ঃ", "ঁ")), K("য", "২", "য়", listOf("২", "য়")),
            K("ড", "৩", "ঢ", listOf("৩", "ঢ")), K("প", "৪", "ফ", listOf("৪", "ফ")),
            K("ট", "৫", "ঠ", listOf("৫", "ঠ")), K("চ", "৬", "ছ", listOf("৬", "ছ")),
            K("জ", "৭", "ঝ", listOf("৭", "ঝ")), K("হ", "৮", "ঞ", listOf("৮", "ঞ")),
            K("গ", "৯", "ঘ", listOf("৯", "ঘ")), K("ড়", "০", "ঢ়", listOf("০", "ঢ়"))
        ),
        listOf(
            K("ৃ", "ঋ", "ঋ", listOf("ঋ", "র্")), K("ু", "উ", "ূ", listOf("উ", "ূ", "ঊ")),
            K("ি", "ই", "ী", listOf("ই", "ী", "ঈ")), K("া", "আ", "অ", listOf("আ", "অ")),
            K("্", null, "্য", listOf("্র", "্য")), K("ব", "ভ", "ভ", listOf("ভ")),
            K("ক", "খ", "খ", listOf("খ", "ক্ষ")), K("ত", "ৎ", "থ", listOf("ৎ", "থ")),
            K("দ", "ধ", "ধ", listOf("ধ"))
        ),
        listOf(
            K("ঁ", "ঃ", "ঃ", listOf("ঃ")), K("ো", "ও", "ৌ", listOf("ও", "ৌ", "ঔ")),
            K("ে", "এ", "ৈ", listOf("এ", "ৈ", "ঐ")), K("র", "ল", "ল", listOf("ল")),
            K("ন", "ণ", "ণ", listOf("ণ")), K("স", "শ", "শ", listOf("শ")),
            K("ম", "ষ", "ষ", listOf("ষ"))
        )
    )

    private val sym1 = listOf(
        "1 2 3 4 5 6 7 8 9 0",
        "@ # \$ % & - + ( ) /",
        "* \" ' : ; ! ?"
    )
    private val sym2 = listOf(
        "~ ` | • ^ ° { } [ ]",
        "\\ < > = _ € £ ¥ ₹ ৳",
        "© ® ™ … § ¿ ¡"
    )
    private val symAlts = mapOf(
        "\$" to listOf("₹", "€", "£", "¥", "৳"), "-" to listOf("–", "—", "_"),
        "!" to listOf("¡"), "?" to listOf("¿"), "'" to listOf("‘", "’"), "\"" to listOf("“", "”")
    )

    private val repeat = object : Runnable {
        override fun run() { backspace(); handler.postDelayed(this, 45) }
    }

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1B1B1B.toInt())
            setPadding(dp(3), dp(6), dp(3), dp(6))
        }
        render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        shift = false
        mode = Mode.LETTERS
        if (::root.isInitialized) render()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        handler.removeCallbacks(repeat)
        dismissPopup()
    }

    private fun render() {
        dismissPopup()
        root.removeAllViews()
        letters.clear()
        shiftView = null
        if (mode == Mode.LETTERS) letterRows() else symbolRows()
        root.addView(bottomRow())
    }

    // ---------- letters ----------

    private fun letterRows() {
        val rows = if (bangla) bnRows else enRows
        rows.forEachIndexed { i, row ->
            val line = newRow()
            if (i == 1 && row.size == 9) line.addView(spacer(0.5f))
            if (i == 2) {
                val sv = keyView("⇧", null, 1.5f, SPECIAL, 18f)
                attach(sv) { shift = !shift; refreshShift(); refreshLetters() }
                shiftView = sv
                line.addView(sv)
            }
            row.forEach { line.addView(letterKey(it)) }
            if (i == 1 && row.size == 9) line.addView(spacer(0.5f))
            if (i == 2) line.addView(backspaceKey())
            root.addView(line)
        }
        refreshShift()
    }

    private fun labelOf(k: K) = if (shift) (if (bangla) k.shifted else k.main.uppercase()) else k.main

    private fun letterKey(k: K): View {
        val v = keyView(labelOf(k), k.hint, 1f, KEY, 20f)
        letters.add(Letter(k, v.getChildAt(0) as TextView, if (v.childCount > 1) v.getChildAt(1) as TextView else null))
        val alts: (() -> List<String>)? = if (k.alts.isEmpty()) null else {
            { k.alts.map { if (shift && !bangla) it.uppercase() else it } }
        }
        attach(v, alts) { typeKey(labelOf(k)) }
        return v
    }

    private fun typeKey(text: String) {
        commit(text)
        if (shift) { shift = false; refreshShift(); refreshLetters() }
    }

    private fun refreshLetters() {
        letters.forEach { l ->
            l.main.text = labelOf(l.k)
            l.hint?.visibility = if (shift) View.INVISIBLE else View.VISIBLE
        }
    }

    private fun refreshShift() {
        shiftView?.let {
            it.background = keyBg(if (shift) ACTIVE else SPECIAL)
            (it.getChildAt(0) as TextView).text = if (shift) "⇩" else "⇧"
        }
    }

    // ---------- symbols ----------

    private fun symbolRows() {
        val rows = if (mode == Mode.SYM1) sym1 else sym2
        rows.forEachIndexed { i, row ->
            val line = newRow()
            if (i == 2) {
                val t = keyView(if (mode == Mode.SYM1) "=\\<" else "?123", null, 1.5f, SPECIAL, 18f)
                attach(t) { mode = if (mode == Mode.SYM1) Mode.SYM2 else Mode.SYM1; render() }
                line.addView(t)
            }
            row.split(" ").forEach { s ->
                val label = if (bangla) toBn(s) else s
                val v = keyView(label, null, 1f, KEY, 20f)
                val a = symAlts[s]
                attach(v, if (a == null) null else ({ a })) { commit(label) }
                line.addView(v)
            }
            if (i == 2) line.addView(backspaceKey())
            root.addView(line)
        }
    }

    // ---------- bottom row ----------

    private fun bottomRow(): View {
        val line = newRow()
        val sym = keyView(if (mode == Mode.LETTERS) "?123" else "ABC", null, 1.5f, SPECIAL, 18f)
        attach(sym) { mode = if (mode == Mode.LETTERS) Mode.SYM1 else Mode.LETTERS; shift = false; render() }
        line.addView(sym)

        val comma = keyView(",", null, 1f, KEY, 20f)
        attach(comma) { commit(",") }
        line.addView(comma)

        line.addView(spaceKey())

        val dotChar = if (bangla) "।" else "."
        val dot = keyView(dotChar, null, 1f, KEY, 20f)
        val dotAlts = if (bangla) listOf(".", "?", "!", ":", ";") else listOf("!", "?", ":", ";", "।")
        attach(dot, { dotAlts }) { commit(dotChar) }
        line.addView(dot)

        val enter = keyView("⏎", null, 1.5f, SPECIAL, 20f)
        attach(enter) { enter() }
        line.addView(enter)
        return line
    }

    private fun spaceKey(): View {
        val v = keyView(if (bangla) "বাংলা  ⇆  English" else "English  ⇆  বাংলা", null, 5f, KEY, 13f)
        var downX = 0f
        var swiped = false
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; swiped = false; view.isPressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                }
                MotionEvent.ACTION_MOVE -> if (!swiped && Math.abs(ev.rawX - downX) > dp(50)) {
                    swiped = true; view.isPressed = false
                    view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    switchLanguage()
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    if (!swiped) commit(" ")
                }
                MotionEvent.ACTION_CANCEL -> view.isPressed = false
            }
            true
        }
        return v
    }

    private fun switchLanguage() { bangla = !bangla; shift = false; render() }

    private fun backspaceKey(): View {
        val v = keyView("⌫", null, 1.5f, SPECIAL, 20f)
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    backspace(); handler.postDelayed(repeat, 380)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false; handler.removeCallbacks(repeat)
                }
            }
            true
        }
        return v
    }

    // ---------- input ----------

    private fun commit(text: String) { currentInputConnection?.commitText(text, 1) }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingText(1, 0)
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ei != null && (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    // ---------- touch + long-press popup ----------
    // Keys with no alternates type instantly on touch-down.
    // Keys with alternates: quick tap types the key on release; hold to open the popup,
    // slide to an option and release to type it (release without sliding types the first one).

    private fun attach(v: View, alts: (() -> List<String>)? = null, tap: () -> Unit) {
        var longShown = false
        var options: List<TextView> = emptyList()
        var values: List<String> = emptyList()
        var sel = 0
        val longPress = Runnable {
            val list = alts?.invoke() ?: return@Runnable
            if (list.isEmpty()) return@Runnable
            values = list
            options = showAlts(v, list)
            sel = 0
            highlight(options, sel)
            longShown = true
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        }
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    longShown = false
                    view.isPressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    if (alts == null) tap() else handler.postDelayed(longPress, 320)
                }
                MotionEvent.ACTION_MOVE -> if (longShown) {
                    val idx = optionAt(options, ev.rawX)
                    if (idx != sel) { sel = idx; highlight(options, sel) }
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    handler.removeCallbacks(longPress)
                    if (longShown) {
                        val chosen = values[sel]
                        dismissPopup()
                        typeKey(chosen)
                    } else if (alts != null) tap()
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    handler.removeCallbacks(longPress)
                    if (longShown) dismissPopup()
                }
            }
            true
        }
    }

    private fun showAlts(anchor: View, alts: List<String>): List<TextView> {
        dismissPopup()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply { setColor(0xFF616161.toInt()); cornerRadius = dp(8).toFloat() }
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val tvs = alts.map { a ->
            TextView(this).apply {
                text = a; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                minWidth = dp(40)
                setPadding(dp(10), dp(8), dp(10), dp(8))
            }.also { row.addView(it) }
        }
        val pw = PopupWindow(row, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pw.isTouchable = false
        pw.isClippingEnabled = false
        row.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        val sw = resources.displayMetrics.widthPixels
        var x = (anchor.width - row.measuredWidth) / 2
        if (loc[0] + x < 0) x = -loc[0]
        if (loc[0] + x + row.measuredWidth > sw) x = sw - row.measuredWidth - loc[0]
        pw.showAsDropDown(anchor, x, -(anchor.height + row.measuredHeight + dp(4)))
        popup = pw
        return tvs
    }

    private fun optionAt(options: List<TextView>, rawX: Float): Int {
        if (options.isEmpty()) return 0
        val loc = IntArray(2)
        options.first().getLocationOnScreen(loc)
        if (options.first().width > 0 && rawX < loc[0]) return 0
        options.forEachIndexed { i, tv ->
            tv.getLocationOnScreen(loc)
            if (tv.width > 0 && rawX >= loc[0] && rawX < loc[0] + tv.width) return i
        }
        return options.size - 1
    }

    private fun highlight(options: List<TextView>, sel: Int) {
        options.forEachIndexed { i, tv ->
            tv.background = if (i == sel)
                GradientDrawable().apply { setColor(ACTIVE); cornerRadius = dp(6).toFloat() }
            else null
        }
    }

    private fun dismissPopup() { popup?.dismiss(); popup = null }

    // ---------- views ----------

    private fun toBn(s: String) = s.map { if (it in '0'..'9') "০১২৩৪৫৬৭৮৯"[it - '0'] else it }.joinToString("")

    private fun newRow() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
    }

    private fun spacer(w: Float) = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, w) }

    private fun keyView(label: String, hint: String?, weight: Float, color: Int, size: Float): FrameLayout {
        val f = FrameLayout(this)
        f.background = keyBg(color)
        f.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
            .apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
        f.addView(TextView(this).apply {
            text = label; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (hint != null) {
            f.addView(TextView(this).apply {
                text = hint; textSize = 10f; setTextColor(0xFFB8B8B8.toInt())
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END).apply { setMargins(0, dp(2), dp(5), 0) })
        }
        return f
    }

    private fun keyBg(color: Int): Drawable {
        fun shape(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(5).toFloat() }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(0xFF7A7A7A.toInt()))
            addState(intArrayOf(), shape(color))
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
